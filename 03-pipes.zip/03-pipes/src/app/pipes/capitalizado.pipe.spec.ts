import { CapitalizadoPipe } from './capitalizado.pipe';

describe('CapitalizadoPipe', () => {
  it('create an instance', () => {
    const pipe = new CapitalizadoPipe();
    expect(pipe).toBeTruthy();
  });
});
